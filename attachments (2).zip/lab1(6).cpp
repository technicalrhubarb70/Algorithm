#include <iostream>

using namespace std;


void printList(int *A, int n){
    for(int i=0; i<n; i++){
        //cout<<(A+i)<<" "<<*(A+i)<<" "<<A[i]<<endl;
        cout<<A[i]<<" "<<endl;
        //cout<<endl;

int * makedouble(int*1, int n){
for(int i=0; i<n;i++)
    p[i]=p[i]*2;
    return 1;
}
    }

int main(){
    int a[5]={10,20,30,40,50};
    int *k = makedouble(a,5)


    return 0;
    }

