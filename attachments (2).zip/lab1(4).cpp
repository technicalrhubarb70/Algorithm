#include <iostream>

using namespace std;

int main(){
    cout<<"Please enter the size of the array"<<endl;
    int n;
    cin>>n;
    int a[n];

    return 0;
    }
