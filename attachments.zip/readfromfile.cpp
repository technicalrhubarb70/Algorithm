#include <iostream>
#include <fstream>

using namespace std;

int search(int arr[], int N, int x) {
    for (int i = 0; i < N; i++) {
        if (arr[i] == x) {
            return i;
        }
    }
    return -1;
}

int main() {
    const int n = 100000;
    int *a = new int[n];

    ifstream fin("100k.txt");

    for (int i = 0; i < n; i++) {
        fin >> a[i];
    }

    int x = 19780;
    int N = n;

    int result = search(a, N, x);

    if (result == -1) {
        cout << "Element is not present in array" << endl;
    } else {
        cout << "Element is present at index " << result << endl;
    }



    return 0;
}


